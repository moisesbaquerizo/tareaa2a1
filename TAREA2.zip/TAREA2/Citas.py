class Citas:
    def __init__(self, id, Agenda, des):
        self.id = id
        self.Agenda = Agenda
        self.descipcion = des
