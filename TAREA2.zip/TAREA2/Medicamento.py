class Medicamento:
    def __init__(self,Id,nom_co,nom_ge,num_re,fe_ela, fe_cad, lote, pvp):
        self.id=Id
        self.nom_co=nom_co
        self.nombre_generico=nom_ge
        self.numero_registro=num_re
        self.fecha_elaboracion=fe_ela
        self.fecha_caducidad=fe_cad
        self.lote=lote
        self.pvp=pvp

    def MostrarMedicamento(self):
        return f"{self.nom_co}"

