class Empresa:
    def __init__(self,razon="Clinica Cigueña",ruc="0943213456001", correo="epardos@unemi.edu.ec",tel="0992255432",dir="Milagro"):
        self.razon_social=razon
        self.ruc=ruc
        self.correo=correo
        self.tel=tel
        self.dir=dir

if __name__ == '__main__':
    emp = Empresa()
    print("__________________________")
    print("empresa")
    print(emp.nombre)