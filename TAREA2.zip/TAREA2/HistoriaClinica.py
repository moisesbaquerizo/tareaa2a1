from Paciente import Paciente
class Historia_Clinica_Paciente:
    def __init__(self, id, ced, ciu, estado, tele, ante):
        self.id = id
        self.id_paciente= []
        self.descipcion = ced
        self.Ciudad = ciu
        self.estado_civil = estado
        self.telefono = tele
        self.antescedentes = ante
    def MostrarPaciente(self, id, nombre, identificacion, fe_nacimiento, nacionalidad, direccion, estadocivil, telefono, tiposangre, antesedentes):
        #Composicion
        p= Paciente(id, nombre, identificacion, fe_nacimiento, nacionalidad, direccion, estadocivil, telefono, tiposangre, antesedentes)
        return p.nombre

His=Historia_Clinica_Paciente(1,"07066108998","Ponce Enriquez","Soltero","0969323907","Sin antescedentes")
print(His.MostrarPaciente(2, "Camilo Ponce","09729","0/12/1991","ecuatoriano","Quito","Soltero","09828","O+","N/A"))