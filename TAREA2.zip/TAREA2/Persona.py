from abc import ABC, abstractmethod

class Persona:
    def __init__(self, id, nom, ident, Fe_Na, dir, tel):
        self.nombre = nom
        self.identificacion = ident
        self.Fe_Nacimiento = Fe_Na
        self.direccion = dir
        self.telefono = tel
        self.__id = id

    def mostrarDatos(self):
        print(self.nombre, self.identificacion, self.Fe_Nacimiento, self.direccion, self.telefono)

#herencia multiple con clase abstracta

class Doctor(Persona, ABC):
    def __init__(self,id, nom, ident, Fe_Na, dir, tel, esp):
        super().__init__(id, nom, ident, Fe_Na, dir, tel)
        self.especialidad = esp

    @abstractmethod
    def validarCedula(self):
        pass

    @property
    def id(self):
        return f'{self.__id}'

    def mostrarDatos(self):
        print(self.nombre, self.identificacion, self.especialidad)

class Enfermera(Persona):
    def __init__(self, id, nom, ident, Fe_Na, dir, tel,area):
        super().__init__(id, nom, ident, Fe_Na, dir, tel)
        self.area = area

    def mostrarDatos(self):
        print(self.nombre, self.identificacion, self.area)
